complete -c b2sum -s l -l length -d 'digest length in bits; must not exceed the max size and must be a multiple of 8 for blake2b; must be 224, 256, 384, or 512 for sha2 or sha3' -r
complete -c b2sum -s b -l binary
complete -c b2sum -s c -l check -d 'read checksums from the FILEs and check them'
complete -c b2sum -s w -l warn -d 'warn about improperly formatted checksum lines'
complete -c b2sum -l status -d 'don\'t output anything, status code shows success'
complete -c b2sum -l quiet -d 'don\'t print OK for each successfully verified file'
complete -c b2sum -l ignore-missing -d 'don\'t fail or report status for missing files'
complete -c b2sum -l strict -d 'exit non-zero for improperly formatted checksum lines'
complete -c b2sum -l tag -d 'create a BSD style checksum'
complete -c b2sum -s t -l text
complete -c b2sum -s z -l zero -d 'end each output line with NUL, not newline, and disable file name escaping'
complete -c b2sum -s h -l help -d 'Print help'
complete -c b2sum -s V -l version -d 'Print version'
